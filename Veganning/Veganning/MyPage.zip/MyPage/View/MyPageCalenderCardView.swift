//
//  MyPageCalenderCardView.swift
//  Veganning
//
//  Created by 김민주 on 8/21/24.
//

import SwiftUI

struct MyPageCalenderCardView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    MyPageCalenderCardView()
}
