//
//  MyPageView.swift
//  Veganning
//
//  Created by 김민솔 on 8/11/24.
//

import SwiftUI

struct MyPageView: View {
    var body: some View {
        Text("mypage")
        Text("마이페이지")//dms
    }
}

#Preview {
    MyPageView()
}
